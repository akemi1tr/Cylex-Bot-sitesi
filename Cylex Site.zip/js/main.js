document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('header');
    const navLinks = document.querySelectorAll('nav ul li a');
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('nav ul');
    const scrollTopBtn = document.createElement('button');
    scrollTopBtn.innerHTML = '↑';
    scrollTopBtn.classList.add('scroll-top-btn');
    document.body.appendChild(scrollTopBtn);

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            const headerHeight = header.offsetHeight;
            const targetPosition = targetSection.offsetTop - headerHeight;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });

            if (navMenu.classList.contains('show')) {
                navMenu.classList.remove('show');
            }
        });
    });

    mobileMenuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('show');
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
            scrollTopBtn.classList.add('show');
        } else {
            header.classList.remove('scrolled');
            scrollTopBtn.classList.remove('show');
        }

        const parallaxElements = document.querySelectorAll('.parallax');
        parallaxElements.forEach(element => {
            const speed = element.dataset.speed || 0.5;
            element.style.transform = `translateY(${window.scrollY * speed}px)`;
        });

        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => {
            if (isInViewport(img)) {
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                img.classList.add('loaded');
            }
        });
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    animatedElements.forEach(element => observer.observe(element));

    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });

    const commandCategories = document.querySelectorAll('.command-category');
    commandCategories.forEach((category, index) => {
        category.style.animationDelay = `${index * 0.1}s`;
    });

    const statCounters = document.querySelectorAll('.stat-item h3');
    statCounters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const step = target / (duration / 16);

        function updateCounter() {
            const current = parseInt(counter.innerText);
            if (current < target) {
                counter.innerText = Math.ceil(current + step);
                setTimeout(updateCounter, 16);
            } else {
                counter.innerText = target;
            }
        }

        updateCounter();
    });

    const testimonialSlider = document.querySelector('.testimonial-slider');
    let isDown = false;
    let startX;
    let scrollLeft;

    testimonialSlider.addEventListener('mousedown', (e) => {
        isDown = true;
        startX = e.pageX - testimonialSlider.offsetLeft;
        scrollLeft = testimonialSlider.scrollLeft;
    });

    testimonialSlider.addEventListener('mouseleave', () => {
        isDown = false;
    });

    testimonialSlider.addEventListener('mouseup', () => {
        isDown = false;
    });

    testimonialSlider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - testimonialSlider.offsetLeft;
        const walk = (x - startX) * 2;
        testimonialSlider.scrollLeft = scrollLeft - walk;
    });

    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('h3');
        question.addEventListener('click', () => {
            item.classList.toggle('active');
        });
    });

    const contactForm = document.querySelector('.contact-form');
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Form submitted successfully!');
        contactForm.reset();
    });

    const newsletterForm = document.querySelector('.newsletter-form');
    newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Subscribed to newsletter successfully!');
        newsletterForm.reset();
    });

    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    const particlesContainer = document.createElement('div');
    particlesContainer.classList.add('particles-container');
    document.body.appendChild(particlesContainer);

    function createParticle() {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.animationDuration = `${Math.random() * 2 + 1}s`;
        particlesContainer.appendChild(particle);

        setTimeout(() => {
            particle.remove();
        }, 3000);
    }

    setInterval(createParticle, 200);

    const typingElement = document.querySelector('.typing-effect');
    const textToType = typingElement.dataset.text;
    let charIndex = 0;

    function typeText() {
        if (charIndex < textToType.length) {
            typingElement.textContent += textToType.charAt(charIndex);
            charIndex++;
            setTimeout(typeText, 100);
        }
    }

    typeText();

    const commandElements = document.querySelectorAll('.command-category ul li code');
    commandElements.forEach(element => {
        element.addEventListener('click', () => {
            const textToCopy = element.textContent;
            navigator.clipboard.writeText(textToCopy).then(() => {
                showCopiedMessage(element);
            });
        });
    });

    function showCopiedMessage(element) {
        const message = document.createElement('span');
        message.textContent = 'Copied!';
        message.classList.add('copied-message');
        element.appendChild(message);

        setTimeout(() => {
            message.remove();
        }, 2000);
    }

    const loadingOverlay = document.createElement('div');
    loadingOverlay.classList.add('loading-overlay');
    const spinner = document.createElement('div');
    spinner.classList.add('spinner');
    loadingOverlay.appendChild(spinner);
    document.body.appendChild(loadingOverlay);

    window.addEventListener('load', () => {
        setTimeout(() => {
            loadingOverlay.style.opacity = '0';
            setTimeout(() => {
                loadingOverlay.remove();
            }, 500);
        }, 1000);
    });

    const heavyElements = document.querySelectorAll('.performance-optimized');
    heavyElements.forEach(element => {
        element.style.willChange = 'transform, opacity';
    });

    function debounce(func, wait = 20, immediate = true) {
        let timeout;
        return function() {
            const context = this, args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    const optimizedScroll = debounce(() => {
    });

    window.addEventListener('scroll', optimizedScroll);

    const lazyLoadImages = document.querySelectorAll('img[data-src]');
    const lazyLoadObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });

    lazyLoadImages.forEach(img => lazyLoadObserver.observe(img));

    if (!('scrollBehavior' in document.documentElement.style)) {
        import('smoothscroll-polyfill').then(smoothScroll => {
            smoothScroll.polyfill();
        });
    }

    const themeToggle = document.createElement('button');
    themeToggle.innerHTML = '🌓';
    themeToggle.classList.add('theme-toggle');
    document.body.appendChild(themeToggle);

    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        localStorage.setItem('theme', document.body.classList.contains('light-theme') ? 'light' : 'dark');
    });

    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
    }

    const cursor = document.createElement('div');
    cursor.classList.add('custom-cursor');
    document.body.appendChild(cursor);

    document.addEventListener('mousemove', (e) => {
        cursor.style.left = `${e.clientX}px`;
        cursor.style.top = `${e.clientY}px`;
    });

    const interactiveElements = document.querySelectorAll('a, button, .interactive');
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            cursor.classList.add('hover');
        });
        element.addEventListener('mouseleave', () => {
            cursor.classList.remove('hover');
        });
    });

    AOS.init({
        duration: 1000,
        once: true,
        offset: 100
    });

    const videoPlayer = document.querySelector('.video-player');
    const video = videoPlayer.querySelector('video');
    const playPauseBtn = videoPlayer.querySelector('.play-pause-btn');
    const seekBar = videoPlayer.querySelector('.seek-bar');

    playPauseBtn.addEventListener('click', togglePlayPause);
    video.addEventListener('timeupdate', updateSeekBar);
    seekBar.addEventListener('change', seekVideo);

    function togglePlayPause() {
        if (video.paused) {
            video.play();
            playPauseBtn.textContent = '❚❚';
        } else {
            video.pause();
            playPauseBtn.textContent = '▶';
        }
    }

    function updateSeekBar() {
        seekBar.value = (video.currentTime / video.duration) * 100;
    }

    function seekVideo() {
        const time = video.duration * (seekBar.value / 100);
        video.currentTime = time;
    }

    const contentContainer = document.querySelector('.infinite-scroll-container');
    let page = 1;

    function loadMoreContent() {
        fetch(`/api/content?page=${page}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(item => {
                    const element = createContentElement(item);
                    contentContainer.appendChild(element);
                });
                page++;
            });
    }

    function createContentElement(item) {
        const element = document.createElement('div');
        element.classList.add('content-item');
        element.innerHTML = `
            <h3>${item.title}</h3>
            <p>${item.description}</p>
        `;
        return element;
    }

    const infiniteScrollObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            loadMoreContent();
        }
    });

    const loadMoreTrigger = document.querySelector('.load-more-trigger');
    if (loadMoreTrigger) {
        infiniteScrollObserver.observe(loadMoreTrigger);
    }
});