document.addEventListener('DOMContentLoaded', () => {
    const languageToggle = document.getElementById('languageToggle');
    const elements = document.querySelectorAll('[data-tr]');
    let currentLanguage = 'tr';

    languageToggle.addEventListener('click', () => {
        currentLanguage = currentLanguage === 'tr' ? 'en' : 'tr';
        updateLanguage();
    });

    function updateLanguage() {
        elements.forEach(element => {
            element.textContent = element.getAttribute(`data-${currentLanguage}`);
        });

        languageToggle.textContent = currentLanguage === 'tr' ? 'EN' : 'TR';
        document.title = currentLanguage === 'tr' ? 'Gizlilik Politikası - Cylex Bot' : 'Privacy Policy - Cylex Bot';
    }

    const scrollTopBtn = document.getElementById('scrollTopBtn');

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const navLinksMenu = document.querySelector('.nav-links');
    const header = document.querySelector('header');

    hamburgerMenu.addEventListener('click', () => {
        navLinksMenu.classList.toggle('active');
        hamburgerMenu.classList.toggle('active');
        document.body.classList.toggle('menu-open');
        
       
        if (navLinksMenu.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });

    document.addEventListener('click', (event) => {
        const isClickInsideMenu = navLinksMenu.contains(event.target);
        const isClickOnHamburger = hamburgerMenu.contains(event.target);

        if (!isClickInsideMenu && !isClickOnHamburger && navLinksMenu.classList.contains('active')) {
            navLinksMenu.classList.remove('active');
            hamburgerMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
            document.body.style.overflow = '';
        }
    });

    navLinksMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinksMenu.classList.remove('active');
            hamburgerMenu.classList.remove('active');
            document.body.classList.remove('menu-open');
            document.body.style.overflow = '';
        });
    });

 
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

  
    const privacySections = document.querySelectorAll('.privacy-section');
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    privacySections.forEach(section => {
        observer.observe(section);
    });
});