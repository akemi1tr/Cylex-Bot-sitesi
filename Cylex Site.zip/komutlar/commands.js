document.addEventListener('DOMContentLoaded', () => {
    const commandSearch = document.getElementById('commandSearch');
    const searchButton = document.getElementById('searchButton');
    const sortSelect = document.getElementById('sortSelect');
    const categoryButtons = document.querySelectorAll('.category-btn');
    const commandsGrid = document.querySelector('.commands-grid');
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const navLinks = document.querySelector('.nav-links');

    
    const commands = [
        // Ekonomi Komutları
        { name: '/günlük', category: 'ekonomi', description: 'Günlük ödülünüzü alın.', usage: 1000, cooldown: '24s', permission: 'Yok' },
        { name: '/param', category: 'ekonomi', description: 'Kendi veya başka bir kullanıcının parasını görüntüleyin.', usage: 1500, cooldown: '5s', permission: 'Yok' },
        { name: '/gönder', category: 'ekonomi', description: 'Başka bir kullanıcıya coin gönderin.', usage: 1200, cooldown: '10s', permission: 'Yok' },
        { name: '/sıralama', category: 'ekonomi', description: 'En zengin kullanıcıların sıralamasını görüntüleyin.', usage: 1800, cooldown: '30s', permission: 'Yok' },
        { name: '/blackjack', category: 'ekonomi', description: 'Blackjack oynayın.', usage: 2000, cooldown: '10s', permission: 'Yok' },
        { name: '/slot', category: 'ekonomi', description: 'Slot makinesi oyunu oynayın.', usage: 1900, cooldown: '10s', permission: 'Yok' },
        { name: '/rulet', category: 'ekonomi', description: 'Rulet çevirerek para kazanma şansı yakalayın.', usage: 1700, cooldown: '10s', permission: 'Yok' },
        { name: '/at-yarışı', category: 'ekonomi', description: 'At yarışı oynayarak para kazanma şansı yakalayın.', usage: 1600, cooldown: '15s', permission: 'Yok' },
        { name: '/mines', category: 'ekonomi', description: 'Mayın tarlası benzeri bir oyun oynayın.', usage: 1400, cooldown: '10s', permission: 'Yok' },

        // Moderasyon Komutları
        { name: '/ban', category: 'moderasyon', description: 'Bir kullanıcıyı sunucudan yasaklar.', usage: 500, cooldown: '5s', permission: 'Yönetici' },
        { name: '/banlist', category: 'moderasyon', description: 'Sunucudaki banlı kullanıcıları listeler.', usage: 300, cooldown: '10s', permission: 'Yönetici' },
        { name: '/davet', category: 'moderasyon', description: 'Kullanıcının davet istatistiklerini gösterir.', usage: 800, cooldown: '5s', permission: 'Yok' },
        { name: '/davetsistemi', category: 'moderasyon', description: 'Davet sistemini yönetir.', usage: 200, cooldown: '30s', permission: 'Yönetici' },
        { name: '/destek-sistemi', category: 'moderasyon', description: 'Acayip gelişmiş destek sistemi oluşturur.', usage: 150, cooldown: '60s', permission: 'Yönetici' },
        { name: '/giriş-çıkış', category: 'moderasyon', description: 'Giriş Çıkış Sistemini Ayarlar.', usage: 250, cooldown: '30s', permission: 'Yönetici' },
        { name: '/güvenlik-log', category: 'moderasyon', description: 'Güvenlik log sistemini yönetir.', usage: 180, cooldown: '30s', permission: 'Yönetici' },
        { name: '/kilit', category: 'moderasyon', description: 'Kanalı kilitler, kilidini açar veya süreli kilitler.', usage: 400, cooldown: '10s', permission: 'Kanal Yönetimi' },
        { name: '/kick', category: 'moderasyon', description: 'Belirtilen kullanıcıyı sunucudan atar.', usage: 350, cooldown: '5s', permission: 'Üyeleri At' },
        { name: '/linkengel', category: 'moderasyon', description: 'Link engelleme sistemini yönetir.', usage: 220, cooldown: '30s', permission: 'Yönetici' },
        { name: '/log-ayarla', category: 'moderasyon', description: 'Log sistemini ayarlar.', usage: 190, cooldown: '30s', permission: 'Yönetici' },
        { name: '/mute', category: 'moderasyon', description: 'Belirtilen kullanıcıyı susturur.', usage: 450, cooldown: '5s', permission: 'Mesajları Yönet' },
        { name: '/otorol', category: 'moderasyon', description: 'Otomatik rol sistemini ayarlar.', usage: 230, cooldown: '30s', permission: 'Yönetici' },
        { name: '/sil', category: 'moderasyon', description: 'Belirtilen sayıda mesajı siler.', usage: 600, cooldown: '5s', permission: 'Mesajları Yönet' },
        { name: '/sunucu-kur', category: 'moderasyon', description: 'Gelişmiş sunucu kurma seçenekleri sunar.', usage: 100, cooldown: '60s', permission: 'Yönetici' },
        { name: '/atlas', category: 'moderasyon', description: 'Bot hakkında bilgi verir.', usage: 700, cooldown: '10s', permission: 'Yok' },
        { name: '/toplu-rol', category: 'moderasyon', description: 'Belirtilen rolü tüm üyelere verir veya alır.', usage: 120, cooldown: '60s', permission: 'Yönetici' },
        { name: '/warn', category: 'moderasyon', description: 'Kullanıcıya uyarı verir ve isteğe bağlı ceza uygular.', usage: 380, cooldown: '10s', permission: 'Mesajları Yönet' },

        // Level Komutları
        { name: '/level', category: 'level', description: 'Bir kullanıcının seviyesini görüntüler.', usage: 1300, cooldown: '5s', permission: 'Yok' },
        { name: '/level-ekle', category: 'level', description: 'Kullanıcıya level ekler (Yönetici gerektirir).', usage: 200, cooldown: '10s', permission: 'Yönetici' },
        { name: '/level-sil', category: 'level', description: 'Kullanıcıdan level siler (Yönetici gerektirir).', usage: 180, cooldown: '10s', permission: 'Yönetici' },
        { name: '/level-sistem-ac', category: 'level', description: 'Level sistemini açar (Yönetici gerektirir).', usage: 150, cooldown: '30s', permission: 'Yönetici' },
        { name: '/level-sistem-kapat', category: 'level', description: 'Level sistemini kapatır (Yönetici gerektirir).', usage: 140, cooldown: '30s', permission: 'Yönetici' },
        { name: '/toplevel', category: 'level', description: 'Sunucunun level sıralamasını görüntüler.', usage: 1100, cooldown: '30s', permission: 'Yok' },

        // Kullanıcı Komutları
        { name: '/afk', category: 'kullanici', description: 'AFK moduna geçer veya çıkar.', usage: 900, cooldown: '5s', permission: 'Yok' },
        { name: '/avatar', category: 'kullanici', description: 'Kullanıcının avatarını gösterir.', usage: 1600, cooldown: '5s', permission: 'Yok' },
        { name: '/banner', category: 'kullanici', description: 'Kullanıcının bannerını gösterir.', usage: 1400, cooldown: '5s', permission: 'Yok' },
        { name: '/profil', category: 'kullanici', description: 'Kullanıcının gelişmiş profilini gösterir.', usage: 1500, cooldown: '10s', permission: 'Yok' },
        { name: '/sunucubilgi', category: 'kullanici', description: 'Sunucu hakkında detaylı bilgi verir.', usage: 800, cooldown: '30s', permission: 'Yok' },
        { name: '/spotify', category: 'kullanici', description: 'Spotify kartına göz atarsın.', usage: 1300, cooldown: '10s', permission: 'Yok' },
        { name: '/kıyasla', category: 'kullanici', description: 'İki kullanıcıyı kıyaslar.', usage: 850, cooldown: '10s', permission: 'Yok' },
        { name: '/öneri', category: 'kullanici', description: 'Bir öneri gönderir.', usage: 700, cooldown: '30s', permission: 'Yok' },

        // Oyun Komutları
        { name: '/trivia', category: 'oyun', description: 'Trivia oyunu başlatır veya sıralamayı gösterir.', usage: 1700, cooldown: '30s', permission: 'Yok' },
        { name: '/matematik', category: 'oyun', description: 'İki kişilik hızlı matematik oyunu başlatır.', usage: 1500, cooldown: '30s', permission: 'Yok' },
        { name: '/kelime-karistirma', category: 'oyun', description: 'Kelime karıştırma oyunu başlatır.', usage: 1800, cooldown: '30s', permission: 'Yok' },
        { name: '/adam-asmaca', category: 'oyun', description: 'Adam asmaca oyunu başlatır.', usage: 1600, cooldown: '30s', permission: 'Yok' },
        { name: '/ship', category: 'oyun', description: 'Sana en uygun kişiyi bulur.', usage: 2500, cooldown: '10s', permission: 'Yok' },
        { name: '/waifu', category: 'oyun', description: 'Rastgele bir anime waifu gönderir.', usage: 2300, cooldown: '10s', permission: 'Yok' },
        { name: '/hikaye', category: 'oyun', description: 'İnteraktif bir hikaye başlatır.', usage: 1400, cooldown: '60s', permission: 'Yok' },
        { name: '/öldür', category: 'oyun', description: 'Bir kullanıcıya saldırırsın.', usage: 1000, cooldown: '10s', permission: 'Yok' },
        { name: '/öp', category: 'oyun', description: 'Bir kullanıcıyı öpersin.', usage: 1200, cooldown: '10s', permission: 'Yok' },
        { name: '/sarıl', category: 'oyun', description: 'Bir kullanıcıya sarılırsın.', usage: 1100, cooldown: '10s', permission: 'Yok' },
        { name: '/şaplak', category: 'oyun', description: 'Bir kullanıcıya şaplak atarsın.', usage: 950, cooldown: '10s', permission: 'Yok' },
        { name: '/lezbiyen-test', category: 'oyun', description: 'Lezbiyenlik yüzdesini ölçer.', usage: 2100, cooldown: '10s', permission: 'Yok' },
        { name: '/gay-test', category: 'oyun', description: 'Gaylik yüzdesini ölçer.', usage: 2200, cooldown: '10s', permission: 'Yok' },
        { name: '/efkarli-test', category: 'oyun', description: 'Efkarlılık yüzdesini ölçer.', usage: 2000, cooldown: '10s', permission: 'Yok' }
    ];

  
    function displayCommands(filteredCommands) {
        commandsGrid.innerHTML = '';
        filteredCommands.forEach((command, index) => {
            const commandCard = document.createElement('div');
            commandCard.classList.add('command-card', 'animate__animated', 'animate__fadeIn');
            commandCard.style.animationDelay = `${index * 0.1}s`;
            commandCard.innerHTML = `
                <span class="category-badge ${command.category}">${command.category}</span>
                <h3>${command.name}</h3>
                <p>${command.description}</p>
                <div class="command-info">
                    <span class="cooldown">Bekleme: ${command.cooldown}</span>
                    <span class="permission">İzin: ${command.permission}</span>
                </div>
                <p>Kullanım: ${command.usage} kez</p>
            `;
            commandsGrid.appendChild(commandCard);
        });
    }

    
    displayCommands(commands);

   
    function searchCommands() {
        const searchTerm = commandSearch.value.toLowerCase();
        const filteredCommands = commands.filter(command => 
            command.name.toLowerCase().includes(searchTerm) || 
            command.description.toLowerCase().includes(searchTerm)
        );
        commandsGrid.style.opacity = '0';
        setTimeout(() => {
            displayCommands(filteredCommands);
            commandsGrid.style.opacity = '1';
        }, 300);
    }

   
    searchButton.addEventListener('click', searchCommands);
    commandSearch.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            searchCommands();
        }
    });

   
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.dataset.category;
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filteredCommands = category === 'all' 
                ? commands 
                : commands.filter(command => command.category === category);
            commandsGrid.style.opacity = '0';
            setTimeout(() => {
                displayCommands(filteredCommands);
                commandsGrid.style.opacity = '1';
            }, 300);
        });
    });

  
    sortSelect.addEventListener('change', () => {
        const sortValue = sortSelect.value;
        let sortedCommands = [...commands];

        switch (sortValue) {
            case 'az':
                sortedCommands.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'za':
                sortedCommands.sort((a, b) => b.name.localeCompare(a.name));
                break;
            case 'usage':
                sortedCommands.sort((a, b) => b.usage - a.usage);
                break;
        }

        commandsGrid.style.opacity = '0';
        setTimeout(() => {
            displayCommands(sortedCommands);
            commandsGrid.style.opacity = '1';
        }, 300);
    });

   
    hamburgerMenu.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburgerMenu.classList.toggle('active');
    });

   
    document.addEventListener('click', (event) => {
        const isClickInsideMenu = navLinks.contains(event.target);
        const isClickOnHamburger = hamburgerMenu.contains(event.target);

        if (!isClickInsideMenu && !isClickOnHamburger && navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
            hamburgerMenu.classList.remove('active');
        }
    });

   
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            hamburgerMenu.classList.remove('active');
        });
    });

   
    window.addEventListener('load', () => {
        document.body.classList.add('loaded');
    });

   
    function revealOnScroll() {
        const elements = document.querySelectorAll('.command-card');
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementBottom = element.getBoundingClientRect().bottom;
            if (elementTop < window.innerHeight && elementBottom > 0) {
                element.classList.add('visible');
            } else {
                element.classList.remove('visible');
            }
        });
    }

    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll(); 
});